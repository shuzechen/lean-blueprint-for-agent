# opencode-plugin-leanblueprint

OpenCode plugin for rendering Lean 4 blueprint dependency graphs from structured theorem data.

## Install

```bash
opencode plugin opencode-plugin-leanblueprint
```

Or add to `~/.config/opencode/config.json`:
```json
{
  "plugin": ["opencode-plugin-leanblueprint"]
}
```

## Prerequisites

### Required

```bash
pip install plastex plastexdepgraph leanblueprint
```

| Package | Purpose |
|---------|---------|
| Python 3.7+ | Runtime for plasTeX |
| `plastex` | LaTeX → HTML compiler |
| `plastexdepgraph` | Dependency graph generation (DOT → d3-graphviz) |
| `leanblueprint` | Blueprint LaTeX macros, CSS, Lean declaration tracking |

### Optional

| Dependency | Purpose | Install |
|-----------|---------|---------|
| `latexmk` + `xelatex` | PDF output | `pip install latexmk` + TeX distribution |
| Lean 4 (`elan`) | `.lean` code generation + `lake build` | https://lean-lang.org/lean4/doc/setup.html |
| Git | Project scaffolding (auto-init if missing) | https://git-scm.com |

## How it works

The plugin adds a `leanblueprint_render` tool that converts structured JSON into a leanblueprint dependency graph:

1. **Agent receives** a JSON description of theorems, their statements, dependencies, and formalization status
2. **Plugin scaffolds** the `blueprint/src/` directory with LaTeX files
3. **plasTeX compiles** the TeX to HTML (or PDF via xelatex)
4. **Output** is placed in `blueprint/web/` (HTML) or `blueprint/print/` (PDF)

The HTML output includes a color-coded interactive dependency graph showing which theorems are formalized, ready, or still in progress.

When `generate_lean: true`, the plugin also generates Lean 4 `.lean` source files and a `lakefile.lean` for compilation.

## JSON Schema

See `AGENTS.md` for the full schema and usage examples for LLM agents.

## License

MIT
