import { tool, type ToolContext, type ToolDefinition } from "@opencode-ai/plugin/tool"
import { BlueprintInput } from "./schema"
import { scaffold } from "./scaffold"
import { buildWeb, buildPdf, buildLean } from "./build"
import { generateContent } from "./content-generator"
import { generateLeanFiles, fillLeanDecls, toLeanPkgName } from "./lean-generator"
import { writeFileSync, existsSync } from "fs"
import { join } from "path"

const DESCRIPTION = `Render a Lean blueprint dependency graph from structured theorem data.

This tool converts a JSON description of mathematical theorems, their proofs, and interdependencies into a color-coded interactive HTML dependency graph (or PDF) using the Lean blueprint system. It can also generate Lean 4 source code files.

Use this tool when the user wants to visualize mathematical theorem dependencies, create a blueprint for a Lean formalization project, or explore the dependency structure of a set of theorems.

The input describes chapters containing items (theorems, lemmas, propositions, corollaries, definitions) with:
- A unique id for each item
- The type of statement
- The mathematical statement itself (in LaTeX)
- Dependencies (uses) on other items by their ids
- Formalization status (stated, not_ready, mathlib)
- Optional Lean declaration names (auto-derived from lean.decl if omitted)
- Optional proof text
- Optional Lean 4 code (lean.decl) for generating .lean source files

The tool auto-generates labels for cross-referencing and produces a full blueprint site with an interactive dependency graph where:
- Green = fully formalized
- Blue = ready to formalize (all dependencies done)
- Orange = not ready (missing dependencies)
- Dark green border = already in Mathlib

Output is placed in blueprint/web/ (HTML) or blueprint/print/print.pdf (PDF) relative to the project directory.
Lean files are placed in <ProjectName>/ (e.g. MyProject/Basic.lean).
Set generate_lean=true to generate Lean files, and lean_build=true to also compile them with lake build.`

export const leanblueprintRenderTool: ToolDefinition = tool({
  description: DESCRIPTION,
  args: {
    title: tool.schema.string().describe("Project title"),
    author: tool.schema.string().optional().describe("Author name"),
    home: tool.schema
      .string()
      .optional()
      .describe("Project website URL (default: https://example.com)"),
    github: tool.schema
      .string()
      .optional()
      .describe("GitHub repository URL (default: https://github.com/user/repo)"),
    dochome: tool.schema
      .string()
      .optional()
      .describe(
        "API documentation base URL (default: https://leanprover-community.github.io/mathlib4_docs)"
      ),
    format: tool.schema
      .enum(["html", "pdf"])
      .default("html")
      .describe("Output format"),
    generate_lean: tool.schema
      .boolean()
      .default(false)
      .describe("Also generate Lean 4 .lean source files from lean.decl fields"),
    lean_build: tool.schema
      .boolean()
      .default(false)
      .describe("Run 'lake build' after generating Lean files"),
    chapters: tool.schema
      .array(
        tool.schema.object({
          name: tool.schema.string().describe("Chapter name"),
          items: tool.schema
            .array(
              tool.schema.object({
                id: tool.schema
                  .string()
                  .describe("Unique identifier, e.g. 'add_comm'"),
                type: tool.schema
                  .enum(["theorem", "lemma", "proposition", "corollary", "definition"])
                  .describe("Type of mathematical statement"),
                name: tool.schema
                  .string()
                  .optional()
                  .describe("Display title for the statement"),
                statement: tool.schema
                  .string()
                  .describe("Statement in LaTeX math, e.g. '$a+b=b+a$'"),
                uses: tool.schema
                  .array(tool.schema.string())
                  .optional()
                  .describe("IDs of other items this depends on"),
                lean_decls: tool.schema
                  .array(tool.schema.string())
                  .optional()
                  .describe(
                    "Lean 4 declaration names. Auto-derived from lean.decl if omitted."
                  ),
                status: tool.schema
                  .enum(["stated", "not_ready", "mathlib"])
                  .describe(
                    "Formalization status: stated=formalized, not_ready=not yet, mathlib=in Mathlib"
                  ),
                proof: tool.schema
                  .string()
                  .optional()
                  .describe("Proof text in LaTeX notation"),
                discussion: tool.schema
                  .number()
                  .optional()
                  .describe("GitHub issue number for discussion"),
                lean: tool.schema
                  .object({
                    module: tool.schema
                      .string()
                      .optional()
                      .describe("Lean module path, e.g. 'MyProject.Basic'"),
                    decl: tool.schema
                      .string()
                      .describe(
                        "Full Lean 4 declaration with proof, e.g. 'theorem add_comm (a b : Nat) : a + b = b + a := by ...'"
                      ),
                  })
                  .optional()
                  .describe("Lean 4 source code for this item"),
              })
            )
            .describe("Items in this chapter"),
        })
      )
      .describe("Chapters containing theorem items"),
  },
  async execute(args, ctx: ToolContext) {
    return executeBlueprint(args as BlueprintInput, ctx)
  },
})

async function executeBlueprint(
  input: BlueprintInput,
  ctx: ToolContext
): Promise<{ output: string; metadata: Record<string, unknown> }> {
  const rootDir = ctx.directory

  const srcDir = join(rootDir, "blueprint", "src")
  const contentPath = join(srcDir, "content.tex")

  const existed = existsSync(srcDir)

  if (!existed) {
    ctx.metadata({ title: "Scaffolding blueprint project" })
    const result = scaffold(rootDir, input)

    if (result.errors.length > 0) {
      return {
        output: renderError(result.errors),
        metadata: { success: false, scaffold_errors: result.errors },
      }
    }
  }

  let processedInput = input
  let leanResult: { modules: string[]; leanDir: string; lakefilePath: string } | null = null

  if (input.generate_lean) {
    ctx.metadata({ title: "Generating Lean 4 source files" })
    processedInput = {
      ...input,
      chapters: fillLeanDecls(input.chapters, toLeanPkgName(input.title)),
    }
    leanResult = generateLeanFiles(rootDir, processedInput)

    if (input.lean_build) {
      ctx.metadata({ title: "Building Lean project (lake build)" })
      const lbResult = buildLean(rootDir)
      if (!lbResult.success) {
        return {
          output: renderLeanBuildError(lbResult),
          metadata: {
            success: false,
            lean_build_failed: true,
            lean_modules: leanResult.modules,
            lean_errors: lbResult.stderr,
          },
        }
      }
    }
  }

  writeFileSync(contentPath, generateContent(processedInput), "utf-8")

  const format = input.format || "html"
  ctx.metadata({ title: `Building blueprint (${format})` })

  const buildResult = format === "pdf" ? buildPdf(rootDir) : buildWeb(rootDir)

  if (!buildResult.success) {
    const errors = [buildResult.stderr]
    if (buildResult.stdout) errors.unshift(buildResult.stdout)
    return {
      output: renderBuildError(errors, buildResult.outputPath),
      metadata: {
        success: false,
        format,
        output_path: buildResult.outputPath,
        errors,
      },
    }
  }

  const chapterCount = processedInput.chapters.length
  const itemCount = processedInput.chapters.reduce((sum, ch) => sum + ch.items.length, 0)

  return {
    output: renderSuccess(buildResult.outputPath, format, chapterCount, itemCount, existed, leanResult),
    metadata: {
      success: true,
      format,
      output_path: buildResult.outputPath,
      chapter_count: chapterCount,
      item_count: itemCount,
      ...(leanResult ? {
        lean_generated: true,
        lean_modules: leanResult.modules,
        lean_dir: leanResult.leanDir,
        lean_built: input.lean_build,
      } : {}),
    },
  }
}

function renderSuccess(
  path: string,
  format: string,
  chapters: number,
  items: number,
  existed: boolean,
  leanResult: { modules: string[]; leanDir: string } | null
): string {
  const stateAction = existed ? "Updated" : "Created"
  let msg = `${stateAction} blueprint with ${chapters} chapter(s) and ${items} item(s).

Output (${format}): ${path}

${format === "html" ? "Open blueprint/web/index.html in a browser to view the dependency graph." : "The PDF is ready at the path above."}
`
  if (leanResult && leanResult.modules.length > 0) {
    msg += `
Lean 4 source files generated:
  Directory: ${leanResult.leanDir}
  Modules: ${leanResult.modules.join(", ")}
`
  }
  return msg
}

function renderError(errors: string[]): string {
  return `Blueprint setup failed:

${errors.map((e) => `- ${e}`).join("\n")}

Please install the required dependencies and try again.`
}

function renderBuildError(errors: string[], outputPath: string): string {
  return `Blueprint build failed.

Output directory: ${outputPath}

Errors:
${errors
  .filter(Boolean)
  .map((e) => e.trim())
  .join("\n\n")}

Check the LaTeX source in blueprint/src/content.tex for syntax errors.`
}

function renderLeanBuildError(result: { stdout: string; stderr: string }): string {
  return `Lean 4 build (lake build) failed.

${result.stderr ? `Errors:\n${result.stderr.trim()}` : ""}
${result.stdout ? `\nOutput:\n${result.stdout.trim()}` : ""}

Check the generated .lean files for syntax errors.`
}
