import { existsSync, mkdirSync, writeFileSync } from "fs"
import { join } from "path"
import { execSync } from "child_process"
import type { BlueprintInput } from "./schema"
import {
  generateContent,
  generateWebTex,
  generatePrintTex,
  generateCommonMacros,
  generateWebMacros,
  generatePrintMacros,
  generatePlastexCfg,
  generateLatexmkrc,
  generateBlueprintSty,
  generateExtraStylesCss,
} from "./content-generator"

export interface ScaffoldResult {
  srcDir: string
  alreadyExisted: boolean
  errors: string[]
}

function checkCommand(cmd: string, args: string[]): boolean {
  try {
    execSync(`${cmd} ${args.join(" ")}`, { stdio: "pipe" })
    return true
  } catch {
    return false
  }
}

function checkDependencies(): string[] {
  const errors: string[] = []

  if (!checkCommand("python", ["--version"])) {
    errors.push("Python 3.7+ is required. Install from https://python.org")
    return errors
  }

  try {
    execSync('python -c "import plasTeX"', { stdio: "pipe" })
  } catch {
    errors.push("plasTeX is not installed. Run: pip install plasTeX")
  }

  try {
    execSync('python -c "import plastexdepgraph"', { stdio: "pipe" })
  } catch {
    errors.push("plastexdepgraph is not installed. Run: pip install plastexdepgraph")
  }

  try {
    execSync('python -c "import leanblueprint"', { stdio: "pipe" })
  } catch {
    errors.push("leanblueprint is not installed. Run: pip install leanblueprint")
  }

  return errors
}

function ensureGitRepo(dir: string): string | null {
  try {
    execSync("git rev-parse --git-dir", { cwd: dir, stdio: "pipe" })
    return null
  } catch {
    try {
      execSync("git init", { cwd: dir, stdio: "pipe" })
      return null
    } catch {
      return "Failed to initialize git repository. Is git installed?"
    }
  }
}

export function scaffold(
  rootDir: string,
  input: BlueprintInput
): ScaffoldResult {
  const srcDir = join(rootDir, "blueprint", "src")
  const macrosDir = join(srcDir, "macros")
  const alreadyExisted = existsSync(srcDir)
  const errors: string[] = []

  const depErrors = checkDependencies()
  if (depErrors.length > 0) {
    return { srcDir, alreadyExisted, errors: depErrors }
  }

  const gitErr = ensureGitRepo(rootDir)
  if (gitErr) {
    errors.push(gitErr)
  }

  mkdirSync(macrosDir, { recursive: true })

  const files: [string, string][] = [
    [join(srcDir, "web.tex"), generateWebTex(input)],
    [join(srcDir, "print.tex"), generatePrintTex(input)],
    [join(srcDir, "content.tex"), generateContent(input)],
    [join(macrosDir, "common.tex"), generateCommonMacros()],
    [join(macrosDir, "web.tex"), generateWebMacros()],
    [join(macrosDir, "print.tex"), generatePrintMacros()],
    [join(srcDir, "plastex.cfg"), generatePlastexCfg()],
    [join(srcDir, "latexmkrc"), generateLatexmkrc()],
    [join(srcDir, "blueprint.sty"), generateBlueprintSty()],
    [join(srcDir, "extra_styles.css"), generateExtraStylesCss()],
  ]

  for (const [path, content] of files) {
    writeFileSync(path, content, "utf-8")
  }

  return { srcDir, alreadyExisted, errors }
}
