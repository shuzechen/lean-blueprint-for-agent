import { z } from "zod"

export const BlueprintItemType = z.enum([
  "theorem",
  "lemma",
  "proposition",
  "corollary",
  "definition",
])

export const BlueprintItemStatus = z.enum([
  "stated",
  "not_ready",
  "mathlib",
])

export const LeanCode = z.object({
  module: z
    .string()
    .optional()
    .describe("Lean module path, e.g. 'MyProject.Basic'. Defaults to derived from chapter name."),
  decl: z
    .string()
    .describe(
      "Full Lean 4 declaration: keyword, name, type signature, and proof. E.g. 'theorem add_comm (a b : Nat) : a + b = b + a := by\\n  induction a with\\n  | zero => simp\\n  | succ a ih => simp [ih]'"
    ),
})

export const BlueprintItem = z.object({
  id: z.string().describe("Unique identifier, e.g. 'add_comm'"),
  type: BlueprintItemType.describe("Type of mathematical statement"),
  name: z.string().optional().describe("Display title"),
  statement: z.string().describe("Statement in LaTeX math, e.g. '$a+b=b+a$'"),
  uses: z.array(z.string()).optional().describe("IDs of items this depends on"),
  lean_decls: z
    .array(z.string())
    .optional()
    .describe("Lean declaration names, e.g. ['MyProject.add_comm']. Auto-derived from lean.decl if omitted."),
  status: BlueprintItemStatus.describe(
    "Formalization status: stated=formalized, not_ready=todo, mathlib=in Mathlib"
  ),
  proof: z.string().optional().describe("Proof text in LaTeX"),
  discussion: z.number().optional().describe("GitHub issue number for discussion"),
  lean: LeanCode.optional().describe(
    "Lean 4 source code for this item. When provided, generates .lean files. The lean_decls field is auto-derived from this."
  ),
})

export const Chapter = z.object({
  name: z.string().describe("Chapter name"),
  items: z.array(BlueprintItem).describe("Items in this chapter"),
})

export const BlueprintInput = z.object({
  title: z.string().describe("Project title"),
  author: z.string().optional().describe("Author name"),
  home: z.string().optional().describe("Project website URL"),
  github: z.string().optional().describe("GitHub repository URL"),
  dochome: z.string().optional().describe("API documentation base URL"),
  format: z.enum(["html", "pdf"]).default("html").describe("Output format"),
  generate_lean: z
    .boolean()
    .default(false)
    .describe("Also generate Lean 4 .lean source files from lean.decl fields"),
  lean_build: z
    .boolean()
    .default(false)
    .describe("Run 'lake build' after generating Lean files. Requires Lean 4 (elan) installed."),
  chapters: z.array(Chapter).describe("Theorem chapters"),
})

export type BlueprintInput = z.infer<typeof BlueprintInput>
export type BlueprintItem = z.infer<typeof BlueprintItem>
export type BlueprintItemType = z.infer<typeof BlueprintItemType>
export type BlueprintItemStatus = z.infer<typeof BlueprintItemStatus>
export type Chapter = z.infer<typeof Chapter>
export type LeanCode = z.infer<typeof LeanCode>
