import type { BlueprintInput, BlueprintItem, Chapter, LeanCode } from "./schema"
import { existsSync, mkdirSync, writeFileSync } from "fs"
import { execSync } from "child_process"
import { join } from "path"

export interface LeanGenResult {
  leanDir: string
  modules: string[]
  lakefilePath: string
  errors: string[]
}

export function chapterToModule(projectName: string, chapter: Chapter): string {
  const suffix = chapter.name
    .replace(/[^\w\u4e00-\u9fff]/g, "")
    .replace(/^\d+/, "")
  return `${projectName}.${suffix || "Chapter"}`
}

export function parseDeclName(decl: string): string | null {
  const match = decl.match(/^\s*(?:theorem|lemma|def|example)\s+(\w[\w']*)/)
  return match ? match[1] : null
}

export function deriveLeanDecl(module: string, decl: string): string | null {
  const name = parseDeclName(decl)
  if (!name) return null
  return `${module}.${name}`
}

export function collectLeanDecls(
  chapters: Chapter[],
  projectName: string
): Map<string, string[]> {
  const map = new Map<string, string[]>()
  for (const ch of chapters) {
    const module = chapterToModule(projectName, ch)
    for (const item of ch.items) {
      if (!item.lean?.decl) continue
      const fullName = deriveLeanDecl(module, item.lean.decl)
      if (fullName) {
        const list = map.get(item.id) || []
        list.push(fullName)
        map.set(item.id, list)
      }
    }
  }
  return map
}

export function fillLeanDecls(
  chapters: Chapter[],
  projectName: string
): Chapter[] {
  const declMap = collectLeanDecls(chapters, projectName)
  return chapters.map((ch) => ({
    ...ch,
    items: ch.items.map((item) => {
      if (item.lean_decls && item.lean_decls.length > 0) return item
      const derived = declMap.get(item.id)
      if (derived && derived.length > 0) {
        return { ...item, lean_decls: derived }
      }
      return item
    }),
  }))
}

function escapeLeanString(s: string): string {
  return s
}

function generateModuleContent(
  chapter: Chapter,
  moduleName: string,
  imports: string[]
): string {
  const lines: string[] = []

  for (const imp of imports) {
    lines.push(`import ${imp}`)
  }
  if (imports.length > 0) lines.push("")

  for (const item of chapter.items) {
    if (!item.lean?.decl) continue
    lines.push(item.lean.decl.trim())
    lines.push("")
  }

  if (lines.length === 0) {
    lines.push("-- No Lean declarations in this chapter")
    lines.push("")
  }

  return lines.join("\n")
}

function gatherImports(
  chapters: Chapter[],
  projectName: string
): Map<string, string[]> {
  const moduleToImports = new Map<string, string[]>()

  for (const ch of chapters) {
    const module = chapterToModule(projectName, ch)
    const importSet = new Set<string>()
    for (const item of ch.items) {
      if (!item.uses) continue
      for (const depId of item.uses) {
        for (const otherCh of chapters) {
          if (otherCh === ch) continue
          const hasDep = otherCh.items.some((i) => i.id === depId)
          if (hasDep) {
            importSet.add(chapterToModule(projectName, otherCh))
          }
        }
      }
    }
    if (importSet.size > 0) {
      moduleToImports.set(module, [...importSet].sort())
    }
  }

  return moduleToImports
}

export function generateLeanFiles(
  rootDir: string,
  input: BlueprintInput
): LeanGenResult {
  const projectName = toLeanPkgName(input.title)
  const leanDir = join(rootDir, projectName)
  const errors: string[] = []

  mkdirSync(leanDir, { recursive: true })

  const moduleImports = gatherImports(input.chapters, projectName)
  const modules: string[] = []

  for (const ch of input.chapters) {
    const moduleName = chapterToModule(projectName, ch)
    const hasLean = ch.items.some((item) => item.lean?.decl)
    if (!hasLean) continue

    const shortName = moduleName.slice(projectName.length + 1)
    const filePath = join(leanDir, `${shortName}.lean`)

    const imports = moduleImports.get(moduleName) || []
    const content = generateModuleContent(ch, moduleName, imports)

    const fileContent = Buffer.from(content, "utf-8")
    writeFileSync(filePath, fileContent)
    modules.push(moduleName)
  }

  if (modules.length > 0) {
    const rootContent = modules
      .map((m) => {
        const short = m.slice(projectName.length + 1)
        return `import ${projectName}.${short}`
      })
      .join("\n") + "\n"
    const rootPath = join(leanDir, `${projectName}.lean`)
    writeFileSync(rootPath, Buffer.from(rootContent, "utf-8"))
  }

  const lakefilePath = join(rootDir, "lakefile.lean")
  if (!existsSync(lakefilePath)) {
    const lfContent = `import Lake
open Lake DSL

package «${projectName}» where

@[default_target]
lean_lib ${projectName} where
`
    writeFileSync(lakefilePath, Buffer.from(lfContent, "utf-8"))
  }

  const toolchainPath = join(rootDir, "lean-toolchain")
  if (!existsSync(toolchainPath)) {
    const toolchain = detectLeanVersion()
    if (toolchain) {
      writeFileSync(toolchainPath, toolchain, "utf-8")
    }
  }

  return { leanDir, modules, lakefilePath, errors }
}

export function toLeanPkgName(title: string): string {
  let name = title
    .replace(/[^a-zA-Z0-9\u4e00-\u9fff\s]/g, "")
    .replace(/\s+/g, "")
  if (!name || /^\d/.test(name)) name = "MyProject"
  return name
}

function detectLeanVersion(): string | null {
  try {
    const leanBin = process.env.ELAN_HOME
      ? `${process.env.ELAN_HOME}\\bin\\lean.exe`
      : "D:\\elan\\bin\\lean.exe"
    if (!existsSync(leanBin)) {
      const out = execSync("lean --version", {
        stdio: "pipe",
        encoding: "utf-8",
        timeout: 10_000,
      })
      const match = out.match(/version (\d+\.\d+\.\d+)/)
      if (match) return `leanprover/lean4:v${match[1]}`
    }
    // Use full path to lean to get version
    const out = execSync(`"${leanBin}" --version`, {
      stdio: "pipe",
      encoding: "utf-8",
      timeout: 10_000,
    })
    const match = out.match(/version (\d+\.\d+\.\d+)/)
    if (match) return `leanprover/lean4:v${match[1]}`
  } catch {
    return "leanprover/lean4:v4.29.1"
  }
  return "leanprover/lean4:v4.29.1"
}
