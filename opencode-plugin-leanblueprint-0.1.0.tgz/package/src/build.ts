import { execSync } from "child_process"
import { join } from "path"

export interface BuildResult {
  success: boolean
  outputPath: string
  stdout: string
  stderr: string
}

const UTF8_ENV = { ...process.env, PYTHONUTF8: "1" }

function execOpts(cwd: string, timeout: number) {
  return {
    cwd,
    stdio: "pipe" as const,
    timeout,
    encoding: "utf-8" as BufferEncoding,
    env: UTF8_ENV,
  }
}

export function buildWeb(rootDir: string): BuildResult {
  const srcDir = join(rootDir, "blueprint", "src")

  try {
    const result = execSync("plastex -c plastex.cfg web.tex", execOpts(srcDir, 120_000))
    return {
      success: true,
      outputPath: join(rootDir, "blueprint", "web"),
      stdout: String(result),
      stderr: "",
    }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    return {
      success: false,
      outputPath: join(rootDir, "blueprint", "web"),
      stdout: err.stdout ? String(err.stdout) : "",
      stderr: err.stderr ? String(err.stderr) : err.message || "Unknown error",
    }
  }
}

export function buildPdf(rootDir: string): BuildResult {
  const srcDir = join(rootDir, "blueprint", "src")

  try {
    execSync("latexmk -output-directory=../print print.tex", execOpts(srcDir, 180_000))
    return {
      success: true,
      outputPath: join(rootDir, "blueprint", "print", "print.pdf"),
      stdout: "",
      stderr: "",
    }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    return {
      success: false,
      outputPath: join(rootDir, "blueprint", "print", "print.pdf"),
      stdout: err.stdout ? String(err.stdout) : "",
      stderr: err.stderr ? String(err.stderr) : err.message || "Unknown error",
    }
  }
}

import { existsSync } from "fs"

function findLake(): string | null {
  const candidates = [
    "D:\\elan\\bin\\lake.exe",
  ]
  if (process.env.ELAN_HOME) {
    candidates.unshift(`${process.env.ELAN_HOME}\\bin\\lake.exe`)
  }
  for (const c of candidates) {
    if (existsSync(c)) return c
  }
  return null
}

const LAKE_EXE = findLake()

export function buildLean(rootDir: string): BuildResult {
  if (!LAKE_EXE) {
    return {
      success: false,
      outputPath: rootDir,
      stdout: "",
      stderr: "Lean 4 (lake) not found. Install via elan: https://lean-lang.org/lean4/doc/setup.html",
    }
  }
  try {
    const result = execSync(`${LAKE_EXE} build`, {
      cwd: rootDir,
      stdio: "pipe",
      timeout: 300_000,
      encoding: "utf-8" as BufferEncoding,
      env: { ...process.env },
    })
    return {
      success: true,
      outputPath: rootDir,
      stdout: String(result),
      stderr: "",
    }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    return {
      success: false,
      outputPath: rootDir,
      stdout: err.stdout ? String(err.stdout) : "",
      stderr: err.stderr ? String(err.stderr) : err.message || "Unknown error",
    }
  }
}
