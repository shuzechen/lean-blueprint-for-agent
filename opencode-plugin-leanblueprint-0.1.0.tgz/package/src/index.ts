import type { Plugin } from "@opencode-ai/plugin"
import { leanblueprintRenderTool } from "./tool"

const plugin: Plugin = async () => {
  return {
    tool: {
      leanblueprint_render: leanblueprintRenderTool,
    },
  }
}

export default { server: plugin }
