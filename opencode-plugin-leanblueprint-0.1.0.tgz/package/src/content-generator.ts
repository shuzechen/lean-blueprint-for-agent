import type { BlueprintInput, BlueprintItem, BlueprintItemType } from "./schema"

const TYPE_PREFIX: Record<BlueprintItemType, string> = {
  theorem: "thm",
  lemma: "lem",
  proposition: "prop",
  corollary: "cor",
  definition: "def",
}

const TYPE_ENV: Record<BlueprintItemType, string> = {
  theorem: "theorem",
  lemma: "lemma",
  proposition: "proposition",
  corollary: "corollary",
  definition: "definition",
}

export function makeLabel(type: BlueprintItemType, id: string): string {
  return `${TYPE_PREFIX[type]}:${id}`
}

function usesLine(item: BlueprintItem, resolveLabel: (id: string) => string): string {
  if (!item.uses || item.uses.length === 0) return ""
  const labels = item.uses.map((depId) => resolveLabel(depId)).join(", ")
  return `  \\uses{${labels}}`
}

function leanLine(item: BlueprintItem): string {
  if (!item.lean_decls || item.lean_decls.length === 0) return ""
  return `  \\lean{${item.lean_decls.join(", ")}}`
}

function statusLine(item: BlueprintItem): string {
  switch (item.status) {
    case "stated":
      return "  \\leanok"
    case "not_ready":
      return "  \\notready"
    case "mathlib":
      return "  \\mathlibok"
  }
}

function discussionLine(item: BlueprintItem): string {
  if (item.discussion === undefined) return ""
  return `  \\discussion{${item.discussion}}`
}

function itemBlock(
  item: BlueprintItem,
  label: string,
  resolveLabel: (id: string) => string
): string {
  const env = TYPE_ENV[item.type]
  const optTitle = item.name ? `[${escapeLatex(item.name)}]` : ""
  const lines: string[] = []

  lines.push(`\\begin{${env}}${optTitle}`)
  lines.push(`  \\label{${label}}`)

  const ul = usesLine(item, resolveLabel)
  if (ul) lines.push(ul)

  const ll = leanLine(item)
  if (ll) lines.push(ll)

  lines.push(statusLine(item))

  const dl = discussionLine(item)
  if (dl) lines.push(dl)

  lines.push(`  ${item.statement}`)
  lines.push(`\\end{${env}}`)

  return lines.join("\n")
}

function proofBlock(item: BlueprintItem, label: string): string {
  if (!item.proof) return ""
  const lines: string[] = []
  lines.push("\\begin{proof}")
  lines.push(`  \\proves{${label}}`)
  lines.push(`  ${item.proof}`)
  lines.push("\\end{proof}")
  return lines.join("\n")
}

export function generateContent(input: BlueprintInput): string {
  const idToType = new Map<string, BlueprintItemType>()
  for (const ch of input.chapters) {
    for (const item of ch.items) {
      idToType.set(item.id, item.type)
    }
  }

  const resolveLabel = (id: string): string => {
    const t = idToType.get(id)
    if (!t) return `???:${id}`
    return makeLabel(t, id)
  }

  const parts: string[] = []

  for (const ch of input.chapters) {
    parts.push(`\\chapter{${escapeLatex(ch.name)}}`)
    parts.push("")

    for (const item of ch.items) {
      const label = makeLabel(item.type, item.id)
      parts.push(itemBlock(item, label, resolveLabel))
      const proof = proofBlock(item, label)
      if (proof) {
        parts.push(proof)
      }
      parts.push("")
    }
  }

  return parts.join("\n")
}

function escapeLatex(s: string): string {
  return s
    .replace(/\\/g, "\\textbackslash ")
    .replace(/[&%$#_{}~^]/g, (c) => {
      const map: Record<string, string> = {
        "&": "\\&",
        "%": "\\%",
        "$": "\\$",
        "#": "\\#",
        _: "\\_",
        "{": "\\{",
        "}": "\\}",
        "~": "\\textasciitilde ",
        "^": "\\textasciicircum ",
      }
      return map[c] || c
    })
}

export function generateWebTex(input: BlueprintInput): string {
  const home = input.home || "https://example.com"
  const github = input.github || "https://github.com/user/repo"
  const dochome = input.dochome || "https://leanprover-community.github.io/mathlib4_docs"

  return `% Web version of the blueprint
\\documentclass{report}

\\usepackage{amssymb, amsthm, amsmath}
\\usepackage{hyperref}
\\usepackage[dep_graph]{blueprint}

\\input{macros/common}
\\input{macros/web}

\\home{${home}}
\\github{${github}}
\\dochome{${dochome}}

\\title{${escapeLatex(input.title)}}
${input.author ? `\\author{${escapeLatex(input.author)}}` : ""}

\\begin{document}
\\maketitle
\\input{content}
\\end{document}
`
}

export function generatePrintTex(input: BlueprintInput): string {
  return `% Printable version of the blueprint
\\documentclass[a4paper]{report}

\\usepackage{geometry}

\\usepackage{expl3}

\\usepackage{amssymb, amsthm, mathtools}
\\usepackage[unicode,colorlinks=true,linkcolor=blue,urlcolor=magenta,citecolor=blue]{hyperref}

\\usepackage[warnings-off={mathtools-colon,mathtools-overbracket}]{unicode-math}

\\input{macros/common}
\\input{macros/print}

\\title{${escapeLatex(input.title)}}
${input.author ? `\\author{${escapeLatex(input.author)}}` : ""}

\\begin{document}
\\maketitle
\\input{content}
\\end{document}
`
}

export function generateCommonMacros(): string {
  return `% Macros shared by web and print versions
\\newtheorem{theorem}{Theorem}
\\newtheorem{proposition}[theorem]{Proposition}
\\newtheorem{lemma}[theorem]{Lemma}
\\newtheorem{corollary}[theorem]{Corollary}

\\theoremstyle{definition}
\\newtheorem{definition}[theorem]{Definition}
`
}

export function generateWebMacros(): string {
  return `% Web-only macros
% (Add custom web-only macros here if needed)
`
}

export function generatePrintMacros(): string {
  return `% Print-only macros: dummy definitions for blueprint commands
\\newcommand{\\lean}[1]{}
\\newcommand{\\discussion}[1]{}
\\newcommand{\\leanok}{}
\\newcommand{\\mathlibok}{}
\\newcommand{\\notready}{}
\\ExplSyntaxOn
\\NewDocumentCommand{\\uses}{m}
 {\\clist_map_inline:nn{#1}{\\vphantom{\\ref{##1}}}%
  \\ignorespaces}
\\NewDocumentCommand{\\proves}{m}
 {\\clist_map_inline:nn{#1}{\\vphantom{\\ref{##1}}}%
  \\ignorespaces}
\\ExplSyntaxOff
`
}

export function generatePlastexCfg(): string {
  return `[general]
renderer=HTML5
copy-theme-extras=yes
plugins=plastexdepgraph leanblueprint

[document]
toc-depth=2
toc-non-files=True

[files]
directory=../web/
split-level=0

[html5]
localtoc-level=0
extra-css=extra_styles.css
mathjax-dollars=False
`
}

export function generateLatexmkrc(): string {
  return `# latexmk configuration for pdf blueprint
$pdf_mode = 1;
$pdflatex = 'xelatex -synctex=1';
@default_files = ('print.tex');
`
}

export function generateBlueprintSty(): string {
  return `\\DeclareOption*{}
\\ProcessOptions

\\newcommand{\\graphcolor}[3]{}
`
}

export function generateExtraStylesCss(): string {
  return `/* CSS tweaks for this blueprint */
div.theorem_thmcontent {
\tborder-left: .15rem solid black;
}

div.proposition_thmcontent {
\tborder-left: .15rem solid black;
}

div.lemma_thmcontent {
\tborder-left: .1rem solid black;
}

div.corollary_thmcontent {
\tborder-left: .1rem solid black;
}

div.proof_content {
\tborder-left: .08rem solid grey;
}
`
}
